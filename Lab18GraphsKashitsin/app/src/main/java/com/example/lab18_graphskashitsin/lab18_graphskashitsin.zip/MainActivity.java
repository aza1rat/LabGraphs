package com.example.lab18_graphskashitsin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    GraphView gv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gv = findViewById(R.id.graphView);
    }

    public void onAddClick(View v)
    {
        gv.addNode();
    }

    public void onRemoveClick(View v)
    {
        gv.removeSelectedNodes();
    }

    public void onLinkClick(View v)
    {
        gv.linkSelectedNodes();
    }
}