package com.example.lab18_graphskashitsin;

public class Node {
    public float x,y;
    public Node(float x,float y)
    {
        this.x = x;
        this.y = y;
    }
}
