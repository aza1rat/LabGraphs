package com.example.lab18_graphskashitsin;

import java.util.ArrayList;

public class Graph {
    ArrayList <Node> node = new ArrayList<Node>();
    ArrayList <Link> link = new ArrayList<Link>();

    public void addNode(float x, float y)
    {
        node.add(new Node(x,y));
    }

    public void removeNode(int index)
    {
        if (index < 0) return;
        node.remove(index);
    }

    public void removeLink(int index)
    {
        if (index < 0) return;
        link.remove(index);
    }

    public void addLink(int a,int b)
    {
        link.add(new Link(a,b));
    }
}
